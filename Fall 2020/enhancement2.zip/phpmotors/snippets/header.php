<div id="top-header">
    <img src="/phpmotors/images/site/logo.png" alt="PHP Motors Logo" id="logo">
    <a href="phpmotors/accounts?action=login-page" title="Login or Register with PHP Motors" id="acc">My Account</a>
</div>