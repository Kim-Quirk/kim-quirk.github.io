<!DOCTYPE html>
<html lang="en">

<head>
    <link type="text/css" rel="stylesheet" href="/phpmotors/css/style.css" media="screen">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Vehicle | PHPMotors.com</title>
</head>

<body>
    <div id="wrapper">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav id="mainNav">
            <?php echo $navList; ?>
        </nav>
        <main>
            <h1 id="pageTitle">Add Vehicle</h1>
            <!-- Displays a message if needed -->
            <?php
            if (isset($message)) {
                echo $message;
            }
            ?>
            <form id="addVehicle" action="/phpmotors/vehicles/index.php" method="post">
                <?php echo $classificationList; ?>
                <label for="invMake">Make: </label>
                <input type="text" name="invMake" id="invMake">
                <label for="invModel">Model: </label>
                <input type="text" name="invModel" id="invModel">
                <label for="invDescription">Description: </label>
                <textarea name="invDescription" id="invDescription" rows="4"></textarea>
                <label for="invImage">Image: </label>
                <input type="text" name="invImage" id="invImage" value="phpmotors/images/no-image.png">
                <label for="invThumbnail">Thumbnail: </label>
                <input type="text" name="invThumbnail" id="invThumbnail" value="phpmotors/images/no-image.png">
                <label for="invPrice">Price: </label>
                <input type="number" name="invPrice" id="invPrice" min="0">
                <label for="invStock">Stock: </label>
                <input type="number" name="invStock" id="invStock" min="0">
                <label for="invColor">Color: </label>
                <input type="text" name="invColor" id="invColor">
                <input value="Add Vehicle" id="submitVehicle" type="submit" name="submit">
                <input type="hidden" name="action" value="addVehicle">
            </form>
        </main>
        <hr>
        <footer>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>

        </footer>
    </div><!-- Wrapper ends -->
</body>

</html>