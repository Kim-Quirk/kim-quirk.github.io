<!DOCTYPE html>
<html lang="en">

<head>
    <link type="text/css" rel="stylesheet" href="/phpmotors/css/style.css" media="screen">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration | PHPMotors.com</title>
</head>

<body>
    <div id="wrapper">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav id="mainNav">
            <!-- <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'; ?> -->
            <?php echo $navList; ?>
        </nav>
        <main>
            <h1 id="pageTitle">Create an Account</h1>

            <!-- Displays a message if needed -->
            <?php
            if (isset($message)) {
                echo $message;
            }
            ?>

            <form id="logIn" action="/phpmotors/accounts/index.php" method="post">
                <label for="clientFirstname">First name: </label>
                <input type="text" name="clientFirstname" id="clientFirstName">
                <label for="clientLastname">Last name: </label>
                <input type="text" name="clientLastname" id="clientLastName">
                <label for="clientEmail">Email: </label>
                <input type="email" name="clientEmail" id="clientEmail">
                <label for="clientPassword">Password: </label>
                <input type="password" name="clientPassword" id="clientPassword">
                <input value="Register" id="signIn" type="submit" name="submit">
                <input type="hidden" name="action" value="register">
            </form>

        </main>
        <hr>
        <footer>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>

        </footer>
    </div><!-- Wrapper ends -->
</body>

</html>