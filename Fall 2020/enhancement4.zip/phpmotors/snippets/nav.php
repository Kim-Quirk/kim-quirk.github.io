<ul>
    <li><a href="/phpmotors/view/home.php" title="Go to PHP Motors Home page">Home</a></li>
    <li><a href="/phpmotors/view/template.php" title="Go to PHP Motors classic cars page">Classic</a></li>
    <li><a href="/phpmotors/view/template.php" title="Go to PHP Motors sports cars page">Sports</a></li>
    <li><a href="/phpmotors/view/template.php" title="Go to PHP Motors SUV vehicles page">SUV</a></li>
    <li><a href="/phpmotors/view/template.php" title="Go to PHP Motors truck vehicles page">Trucks</a></li>
    <li><a href="/phpmotors/view/template.php" title="Go to PHP Motors used cars page">Used</a></li>
</ul>