<?php
if (isset($_SESSION['loggedin']) === FALSE) {
    header('Location: /phpmotors/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link type="text/css" rel="stylesheet" href="/phpmotors/css/style.css" media="screen">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | PHPMotors.com</title>
</head>

<body>
    <div id="wrapper">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav id="mainNav">
            <!-- <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'; ?> -->
            <?php echo $navList; ?>
        </nav>
        <main>
            <h1 id="pageTitle"><?php echo $clientData['clientFirstname'], ' ', $clientData['clientLastname']; ?></h1>
            <p id="loggedInMessage">You are logged in.</p>
            <ul>
            <li>Email address: <?php echo $clientData['clientEmail']; ?></li>
            <li>Client level: <?php echo $clientData['clientLevel']; ?></li>
            </ul>

            <?php
            if($clientData['clientLevel'] > 1) {
                echo "<p><a href='/phpmotors/vehicles/index.php' title='Admin page for managing vehicles'>Vehicle Mangement</a></p>";
            }
            ?>
        </main>
        <hr>
        <footer>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>

        </footer>
    </div><!-- Wrapper ends -->
</body>

</html>