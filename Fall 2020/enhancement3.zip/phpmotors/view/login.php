<!DOCTYPE html>
<html lang="en">

<head>
    <link type="text/css" rel="stylesheet" href="/phpmotors/css/style.css" media="screen">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | PHPMotors.com</title>
</head>

<body>
    <div id="wrapper">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav id="mainNav">
            <!-- <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'; ?> -->
            <?php echo $navList; ?>
        </nav>
        <main>
            <h1 id="pageTitle">Sign In</h1>
            <form id="logIn">
                <label for="clientEmail">Email: </label><input name="clientEmail" id="clientEmail" type="email">
                <label for="clientPassword">Password: </label><input name="clientPassword" id="clientPassword" type="password">
                <br/>
                <input value="Sign In" id="signIn" type="button">
            </form>
            <a id="question" href="/phpmotors/accounts/index.php?action=registration" title="Click here to create an account"><p>Not a member yet?</p></a>
        </main>
        <hr>
        <footer>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>

        </footer>
    </div><!-- Wrapper ends -->
</body>

</html>